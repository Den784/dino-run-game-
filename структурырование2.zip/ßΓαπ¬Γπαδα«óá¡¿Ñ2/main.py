from functions import *

pygame.init()

def main():
    game_menu()

if __name__ == '__main__':
    main()

pygame.quit()
