a = 11
b = 24

print(a*b)